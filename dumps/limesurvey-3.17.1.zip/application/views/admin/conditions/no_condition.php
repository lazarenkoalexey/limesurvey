<?php
/**
 * No condition view
 *
 */
?>

<div class="row">
    <div class="col-lg-4">
        <?php echo eT("This question is always shown.");?>
    </div>
</div>
