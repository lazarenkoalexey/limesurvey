<tr>
    <td colspan="6"><?php eT("No quotas have been set for this survey");?></td>
</tr>