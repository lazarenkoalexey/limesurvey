<p><input type='submit' class="btn btn-default hidden" value='<?php eT("Save"); ?>' />
 <input type='hidden' name='id' value='<?php echo $id; ?>' />
 <input type='hidden' name='sid' value='<?php echo $surveyid; ?>' />
 <input type='hidden' name='subaction' value='update' />
 <input type='hidden' name='language' value='<?php echo $sDataEntryLanguage; ?>' /></p>
</div></div></div>