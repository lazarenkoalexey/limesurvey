<?php
/* @var $this AdminController */

// DO NOT REMOVE This is for automated testing to validate we see that page
echo viewHelper::getViewTestTag('expressionsRelevance');
?>

<?php
LimeExpressionManager::UnitTestRelevance();
?>