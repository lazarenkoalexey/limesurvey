          </div>
          <p>
            <input type='submit' class='standardbtn hidden' value='<?php eT("Save");?>' <?php if ($bReadOnly){?>disabled='disabled'<?php }?>/>
          </p>
        </div>
      </form>
      </div>
    </div>
  </div>
</div>
