<br />
<span class='success'><?php eT("Thank you!") ?></span>
<br /><br />
<?php eT("Your survey responses have been recorded.") ?>
<br /><br />
