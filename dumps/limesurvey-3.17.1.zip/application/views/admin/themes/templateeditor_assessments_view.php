<table align='center'>
    <tr>
        <th><?php eT("Assessment heading") ?></th>
    </tr>
    <tr>
        <td align='center'>
            <?php eT("Assessment details") ?><br />
            <?php eT("Note that this assessment section will only show if assessment rules have been set and assessment mode is activated.") ?>
        </td>
    </tr>
</table>
