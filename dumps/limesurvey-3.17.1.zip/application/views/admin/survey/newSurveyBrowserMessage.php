
<script type="text/javascript">
    alert('<?php eT("To be able to upload images or other content you have to save your survey once first.");?>');
    self.close();
</script>