<?php
App()->getClientScript()->registerScript("EditQuestionView_question_jsviews" ,"OtherSelection('".$type."');", LSYii_ClientScript::POS_POSTSCRIPT );
