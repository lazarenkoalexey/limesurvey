    </table>
    <input type='hidden' name='sid' value='<?php echo $surveyid; ?>' />
    <input type='hidden' name='subaction' value='all' />
    <input id='deleteanswer' name='deleteanswer' value='' type='hidden' />
    <input id='downloadfile' name='downloadfile' value='' type='hidden' />
</form><br />
