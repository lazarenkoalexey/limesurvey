<tr>
    <td colspan='2' height='4'>
        <strong><?php eT("Browse responses"); ?>:</strong> <?php echo $surveyinfo['name']; ?>
    </td>
</tr>
<tr>
    <td>
        <table width='100%' align='center' border='0' bgcolor='#EFEFEF'>
            <tr>
                <td align='center'>
                    <?php eT("Showing filtered results"); ?><br />
                    [<a href="javascript:window.close()"><?php eT("Close"); ?></a>]
                </td>
            </tr>
        </table>
    </td>
</tr>
