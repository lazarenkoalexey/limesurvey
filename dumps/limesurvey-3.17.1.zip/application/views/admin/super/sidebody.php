<div id="vue-side-body-app" class='side-body <?php echo getSideBodyClass($sideMenuOpen); ?>'>
    <?php echo $content; ?>
</div>
