<?php
/**
 * Statistic output
 *
 * @var $outputs
 * @var $bSum
 * @var $bAnswer
 */
?>

<!-- _statisticsoutput_header -->
    <div class="col-sm-4 printable" style="margin-top: 2em;margin-bottom: 2em;">
        <h4><?php echo $outputs['qquestion'];?></h4>
<!-- end of _statisticsoutput_header -->
