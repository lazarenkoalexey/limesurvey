<?php
/**
 * This view render the 'no simple graph' message
 */
?>
<div class="row">
    <div class="col-sm-12">
        <div class="alert alert-warning" role="alert"  style="height: 300px;">
            <?php eT('No simple graph for this question type');?>
        </div>
    </div>
</div>
