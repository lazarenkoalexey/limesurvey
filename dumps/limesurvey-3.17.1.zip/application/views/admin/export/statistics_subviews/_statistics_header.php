<!-- views/admin/export/statistics_subviews/_header.php -->
<h3 id="survey-action-title">
    <?php eT("Statistics"); ?>
    <span id="statistics-render-chevron" class="fa fa-chevron-up"></span>
</h3>
