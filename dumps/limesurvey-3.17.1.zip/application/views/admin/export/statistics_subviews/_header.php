<!-- views/admin/export/statistics_subviews/_header.php -->
<h3 id="survey-action-title">
    <?php eT("General filters"); ?>
    <span data-url="/LimeSurveyNext/index.php/admin/survey/sa/togglequickaction" id="generalfilters-chevron" class="fa fa-chevron-up"></span>
</h3>
