<!-- views/admin/export/statistics_subviews/_header.php -->
<h3 id="survey-action-title">
    <?php eT("Response filters"); ?>
    <span data-url="/LimeSurveyNext/index.php/admin/survey/sa/togglequickaction" id="responsefilters-chevron" class="fa fa-chevron-up"></span>
</h3>
