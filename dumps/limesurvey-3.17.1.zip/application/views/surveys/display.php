<?php
/**
 * to display a content with layout 'public'
 * @var string content to be published
 **/
    echo $content;
