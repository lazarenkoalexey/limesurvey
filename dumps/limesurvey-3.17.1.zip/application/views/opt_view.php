<div id="wrapper"><p id="optoutmessage">
<?php
    echo $html;
?>
</p></div>
