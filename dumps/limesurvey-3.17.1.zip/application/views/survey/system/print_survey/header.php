
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<script type="text/javascript" src="<?php echo Yii::app()->getConfig('adminscripts');?>printablesurvey.js"></script>
