<?php
/**
 * @var string content to be published
 **/
    echo $content;
