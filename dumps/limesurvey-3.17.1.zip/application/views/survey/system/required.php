<?php
/**
 * Just add required element before an element
 */
?>
<small class="text-danger asterisk fa fa-asterisk pull-left small" aria-hidden='true'></small><span class="sr-only text-danger asterisk"> (<?php echo gT("Mandatory"); ?>)<span>
