<?php
/**
 * Save all link
 *
 * @var $submit
 * @var $class
 */
?>
<li class="ls-no-js-hidden">
    <a href="#" data-limesurvey-submit='<?php echo $submit ?>' class='<?php echo $class ?>'>
        <?php echo gT("Resume later") ?>
    </a>
</li>
