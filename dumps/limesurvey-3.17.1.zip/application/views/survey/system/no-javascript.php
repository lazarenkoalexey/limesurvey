<?php
/**
 * javacript alert box
 */
?>
<div class='alert alert-danger ls-js-hidden warningjs' data-type='checkjavascript'>
    <?php echo gT("Caution: JavaScript execution is disabled in your browser or for this website. You may not be able to answer all questions in this survey. Please, verify your browser parameters."); ?>
</div>

