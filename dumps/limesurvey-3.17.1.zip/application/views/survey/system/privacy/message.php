<?php
/**
 * privacy message
 */
?>
<p class="ls-privacy-body"><?php echo gT("The record of your survey responses does not contain any identifying information about you, unless a specific survey question explicitly asked for it."); ?><p>
<p class="ls-privacy-body"><?php echo gT("If you used an identifying token to access this survey, please rest assured that this token will not be stored together with your responses. It is managed in a separate database and will only be updated to indicate whether you did (or did not) complete this survey. There is no way of matching identification tokens with survey responses."); ?>
