<?php
/**
 * Heading for privacy
 */
?>
<?php
echo gT("This survey is anonymous.");
