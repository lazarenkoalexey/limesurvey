<?php
/**
 * Heading
 *
 */
?>
<?php echo gT("Exit and clear survey"); ?>
