<?php
/**
 * message
 * @todo : some cmlass ? Review class ?
 */
?>
<p><?php echo gT("Please confirm you want to clear your response?"); ?></p>
