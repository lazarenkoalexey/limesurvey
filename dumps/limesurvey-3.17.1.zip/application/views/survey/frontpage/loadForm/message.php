<?php
/**
 * message
 *
 */
?>
<p><?php echo gT("You can load a survey that you have previously saved from this screen."); ?></p>
<p><?php echo gT("Type in the 'name' you used to save the survey, and the password."); ?></p>
