<?php
/**
 * Heading
 *
 */
?>
<?php echo gT("You must be registered to complete this survey"); ?>
