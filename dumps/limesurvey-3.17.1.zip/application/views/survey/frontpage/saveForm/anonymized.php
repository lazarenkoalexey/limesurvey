<?php
/**
 * Information about aninymized
 * @todo : find a good class
 */
?>
<p><?php echo gT("To remain anonymous please use a pseudonym as your username, also an email address is not required.") ?></p>
