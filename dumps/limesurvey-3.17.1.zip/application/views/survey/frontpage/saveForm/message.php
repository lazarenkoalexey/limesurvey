<?php
/**
 * message
 * @todo : some cmlass ? Review class ?
 */
?>
<p><?php echo gT("Enter a name and password for this survey and click save below."); ?></p>
<p><?php echo gT("Your survey will be saved using that name and password, and can be completed later by logging in with the same name and password."); ?></p>
<p class='info-email-optional ls-info'><?php echo gT("If you give an email address, an email containing the details will be sent to you."); ?></p>
<p><?php echo gT("After having clicked the save button you can either close this browser window or continue filling out the survey."); ?></p>
