<?php
/**
 * Heading
 *
 */
?>
<?php echo gT("To participate in this restricted survey, you need a valid token."); ?>
