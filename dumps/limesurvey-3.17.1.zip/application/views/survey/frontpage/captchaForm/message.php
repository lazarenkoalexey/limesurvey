<?php
/**
 * message
 *
 */
/* Don't add something : don't close PHP tag */
