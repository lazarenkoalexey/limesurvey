<?php
/**
 * Heading
 *
 */
?>
<?php echo gT("Before you start, please prove you are human."); ?>
