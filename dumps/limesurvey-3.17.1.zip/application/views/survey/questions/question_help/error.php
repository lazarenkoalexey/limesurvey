<?php
/**
 * This file render the error message when validating
 * @var $message
 */
?>
<div class="alert alert-warning error <?php echo $classes; ?>" role="alert">
    <?php echo $message;?>
</div>
