<?php
/**
 * Question help. For now, called from SurveyRunTime::getQuestionReplacement
 * @var $questionHelp    $aReplacement['QUESTIONHELP']
 */
?>
<!-- views/survey/system/questionhelp -->
<div class="ls-questionhelp">
    <?php echo $questionHelp; ?>
</div>
