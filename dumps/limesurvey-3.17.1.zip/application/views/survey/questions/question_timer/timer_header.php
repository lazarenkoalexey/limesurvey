<?php
/**
 * This file render the headers of the div containing the timer
 * @var $timersessionname
 * @var $timersessionname
 * @var $time_limit
 */
?>
<div class="timer_header">
