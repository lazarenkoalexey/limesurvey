<?php
/**
 * This file render the timer : not needed anymore, could be rendered directly in timer_content
 * @var $iQid
 * @var $sWarnId
 */
?>

<div style='display: inline' id='LS_question<?php echo $iQid;?>_Warning<?php echo $sWarnId;?>'>
</div>
